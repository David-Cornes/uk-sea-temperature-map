# France sea temperature map setup

## 1. Upload the repository changes

Replace the existing files in the `uk-sea-temperature-map` repository with the files in this package. The existing UK feed remains at:

`https://david-cornes.github.io/uk-sea-temperature-map/uk-water-temperatures.json`

The new France feed will be published at:

`https://david-cornes.github.io/uk-sea-temperature-map/fr-water-temperatures.json`

The existing Copernicus username and password secrets are reused. No new repository secrets are required.

## 2. Run and verify the workflow

In GitHub, open **Actions → Update UK and France Water Temperatures → Run workflow**.

After the run completes, confirm that both JSON URLs open and that every French location has a numeric `temperature_c`. If a location returns `null`, adjust only its `sample_lat` and `sample_lon` in `FR_LOCATIONS`; keep its display `lat` and `lon` unchanged.

## 3. Create the French Shopify page

1. Create a new page template for the French sea-temperature map.
2. Add a **Custom Liquid** section.
3. Paste the complete contents of `shopify/fr-sea-temperature-map.liquid` into that section.
4. Do not add a separate page heading above it; the supplied section already contains the H1 and introductory copy.
5. Publish the page and add its French URL to the homepage button.

Recommended page title and handle:

- Title: `Carte des températures de la mer en France`
- Handle: `temperature-de-la-mer-france`

## 4. Product recommendation sections

Each marker currently links to the appropriate translated Shopify collection. If the France page should also switch visible Featured Collection carousels when a marker is selected, first add the relevant sections to the new page template. Their generated Shopify section IDs will be different from the UK page IDs and must be added only after the French template exists.

Recommended collections by temperature band:

- Under 8 °C: winter wetsuits
- 8–10.9 °C: 5 mm wetsuits
- 11–13.9 °C: 4 mm wetsuits
- 14–16.9 °C: 3/2 mm wetsuits
- 17–19.9 °C: summer wetsuits
- 20 °C and above: rash vests, wetsuit tops and shorty wetsuits

## 5. Homepage panel

Once the live French map is displaying current temperatures, take a clean desktop screenshot for the French homepage panel and use:

- Heading: `Quelle est la température de la mer en France ?`
- Text: `Consultez les dernières températures de la mer sur les côtes françaises et choisissez la combinaison adaptée aux conditions.`
- Button: `Voir la carte en temps réel`
